- Main is contained in "ContainsMain.java".  

- The program takes a single command line argument: the name of a file specifying a graph; the comments in "Graph.java" specify the correct format for this file.  Example input files are provided by "test0.txt" and "test1.txt". 

- Little or no error checking is performed by the program.

- The program is still provisional in that it has not fully been tested and changes might still be made in the future.

Marc Tedder (August 15th, 2008)